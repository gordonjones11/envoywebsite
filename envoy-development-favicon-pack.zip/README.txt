Envoy Development favicon capture pack

Created from a publicly visible Envoy Development company/profile icon captured online, converted into common favicon formats.

Files:
- favicon.ico: multi-size ICO for browser/favicon use.
- favicon-16x16.png, favicon-32x32.png, favicon-48x48.png, favicon-64x64.png, favicon-128x128.png, favicon-180x180.png, favicon-192x192.png, favicon-256x256.png, favicon-512x512.png: PNG renditions.
- apple-touch-icon.png: 180x180 PNG.
- android-chrome-192x192.png and android-chrome-512x512.png: common PWA/icon sizes.
- original-capture.jpg: original 100x100 captured source image.

Note: This is a capture/reconstruction, not the original vector/source file. For best quality, replace with the original asset if it is recovered from the website builder/CMS.
